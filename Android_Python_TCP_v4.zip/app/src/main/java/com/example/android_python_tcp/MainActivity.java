package com.example.android_python_tcp;

import static java.util.logging.Logger.global;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutputStream;

import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity{

    private Button connect_btn; // ip 받아오는 버튼

    public String html = "";
    public Handler mHandler;

    public Socket socket;

    public DataOutputStream dos;
    public DataInputStream dis;

    public String ip = "192.168.0.15"; // IP 번호
    public int port = 9998; // port 번호

    public static Context context_main;

    public String name = "";
    public String birth = "";
    public String feature = "";
    public String lat = "";
    public String lon = "";
    private TextView tv_phonenum, tv_pass;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_phonenum = findViewById(R.id.tv_phonenum);
        tv_pass = findViewById(R.id.tv_pass);
        context_main =this;

        Intent intent = getIntent();
        String userPhoneNum = intent.getStringExtra("userPhoneNum");
        String userPass = intent.getStringExtra("userPass");

        tv_phonenum.setText(userPhoneNum);
        tv_pass.setText(userPass);


        connect_btn = (Button)findViewById(R.id.connect_btn);
        connect_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connect();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);
                    }
                },3000);

            }

        });
    }

    // 로그인 정보 db에 넣어주고 연결시켜야 함.
    void connect(){
        mHandler = new Handler();
        Log.w("connect","연결 하는중");
        Thread checkUpdate = new Thread() {
            public void run() {
                String newip = String.valueOf(ip);

                try {
                    socket = new Socket(newip, port);
                    Log.w("서버 접속됨", "서버 접속됨");
                } catch (IOException e1) {
                    Log.w("서버접속못함", "서버접속못함");
                    e1.printStackTrace();
                }

                Log.w("edit 넘어가야 할 값 : ","안드로이드에서 서버로 연결요청");

                try {
                    dos = new DataOutputStream(socket.getOutputStream()); // output에 보낼꺼 넣음
                    dis = new DataInputStream(socket.getInputStream());

                } catch (IOException e) {
                    e.printStackTrace();
                    Log.w("버퍼", "버퍼생성 잘못됨");
                }
                Log.w("버퍼","버퍼생성 잘됨");

                try {

                        byte[] nameBuf = new byte[3];
                        int nameLen=dis.read(nameBuf);
                        name = new String(nameBuf,"UTF-8").substring(0,nameLen);

                        byte[] birthBuf = new byte[10];
                        int birthLen=dis.read(birthBuf);
                        birth = new String(birthBuf,"UTF-8").substring(0,birthLen);

                        byte[] featureBuf = new byte[7];
                        int featureLen=dis.read(featureBuf);
                        feature = new String(featureBuf,"UTF-8").substring(0,featureLen);

                        byte[] latBuf = new byte[18];
                        int latLen=dis.read(latBuf);
                        lat = new String(latBuf,"UTF-8").substring(0,latLen);

                        byte[] lonBuf = new byte[18];
                        int lonLen=dis.read(lonBuf);
                        lon = new String(lonBuf,"UTF-8").substring(0,lonLen);

                        Log.w("name",""+ name+",len:"+nameLen);
                        Log.w("birth", ""+ birth+",len"+birthLen);
                        Log.w("feature", ""+ feature+",len"+featureLen);
                        Log.w("lat", ""+ lat+",len"+latLen);
                        Log.w("lon", ""+ lon+",len"+lonLen);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        };
        checkUpdate.start();
    }

}