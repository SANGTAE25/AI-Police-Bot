package com.example.android_python_tcp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.content.res.ResourcesCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        String name2 = ((MainActivity)MainActivity.context_main).name;
        String birth2 = ((MainActivity)MainActivity.context_main).birth;
        String feature2 = ((MainActivity)MainActivity.context_main).feature;
        String lat2 = ((MainActivity)MainActivity.context_main).lat;
        String lon2 = ((MainActivity)MainActivity.context_main).lon;

        ImageView imageView = findViewById(R.id.i_imageView);
        TextView t_name = findViewById(R.id.t_name);
        TextView t_feature = findViewById(R.id.t_feature);
        TextView t_birth = findViewById(R.id.t_birth);
        TextView t_lat = findViewById(R.id.t_lat);
        TextView t_lon = findViewById(R.id.t_lon);

        if(name2.equals("LST")){
            imageView.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.lst));
        }

        else{
            imageView.setImageDrawable(AppCompatResources.getDrawable(this, R.drawable.mic));
        }

        t_name.setText(name2);
        t_birth.setText(birth2);
        t_feature.setText(feature2);
        t_lat.setText(lat2);
        t_lon.setText(lon2);

    }
}